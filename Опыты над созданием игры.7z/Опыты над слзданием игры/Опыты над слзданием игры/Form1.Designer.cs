﻿using System.Numerics;
using System.Security.Policy;
using System.Threading;
using Опыты_над_слзданием_игры;

namespace Опыты_над_созданием_игры
{
    public static class ActionMonster
    {
        public static int time = 0;
        public static Dictionary<Direction, Direction> swapDirectionDict = new Dictionary<Direction, Direction>
        {
            { Direction.Left, Direction.Right },
            { Direction.Right, Direction.Left },
            { Direction.Up, Direction.Down },
            { Direction.Down, Direction.Up }
        };

        public static void MoveMonsterRight(PictureBox hitBoxMonster, PictureBox hitBoxWave, int speed)
        {
            while (hitBoxMonster.Left < hitBoxWave.Left + hitBoxWave.Width)
            {
                hitBoxMonster.Left += speed;
            }
        }

        public static void MoveMonsterLeft(PictureBox hitBoxMonster, int deafultLeft, int speed)
        {
            while (deafultLeft < hitBoxMonster.Left)
            {
                hitBoxMonster.Left -= speed;
            }
        }

        private static bool GetResultCondition(PictureBox hitBoxBone, PictureBox hitBoxArea, Direction direction)
        {
            if (direction == Direction.Right)
                return hitBoxBone.Left + hitBoxBone.Width < hitBoxArea.Left + hitBoxArea.Width;
            return hitBoxBone.Left > hitBoxArea.Left;

        }

        public static void MoveBoneHorizontal(Bone model, PictureBox hitBoxBone, PictureBox hitBoxArea, 
            int offsetLeft, int offsetTop, Direction thisDirection)
        {
            if (model.direction == thisDirection)
            {
                if (GetResultCondition(hitBoxBone, hitBoxArea, thisDirection))
                    hitBoxBone.Left += model.speed * ((int)thisDirection);
                else
                {
                    model.direction = model.isReverseMotion ? swapDirectionDict[thisDirection] : model.direction;
                    if (hitBoxBone.Top > hitBoxArea.Top)
                    {
                        hitBoxBone.Top -= offsetTop;
                       
                    }
                    else
                    {
                        hitBoxBone.Top += offsetTop;
                        
                    }
                    hitBoxBone.Left += offsetLeft;
                }
            }
        }

        public static void Attack1(Bone bone, Design design, int indexBone)
        {
            MoveBoneHorizontal(bone, design.hitBoxsBoneAttacks[indexBone], design.hitBoxArea, 0,
                design.hitBoxArea.Height - design.hitBoxsBoneAttacks[indexBone].Height, Direction.Right);
            
            MoveBoneHorizontal(bone, design.hitBoxsBoneAttacks[indexBone], design.hitBoxArea, 0,
                design.hitBoxArea.Height - design.hitBoxsBoneAttacks[indexBone].Height, Direction.Left);
        }

        public static void Attack2(List<Bone> bones, Design design)
        {
            for (int i = 0; i < bones.Count; ++i)
            {
                Attack1(bones[i], design, i);
            }
        }

        public static void Attack3(List<Bone> bones, Design design, int timerAttack)
        {
            for (int i = 0; i < bones.Count; ++i)
            {
                bones[i].isReverseMotion = false;
                design.TryChangeColorBone(design.hitBoxsBoneAttacks[i], bones[i].isBlue);
                if (i == 1 && timerAttack > 5 || i == 2 && timerAttack > 10 || i == 3 && timerAttack > 15 || i == 0)
                {
                    MoveBoneHorizontal(bones[i], design.hitBoxsBoneAttacks[i], design.hitBoxArea, -design.hitBoxArea.Width, 0, Direction.Right);
                }
            }
        }
    }

    public class Design
    {
        public PictureBox hitBoxHeart;
        public PictureBox hitBoxIndicationHealth;
        public PictureBox hitBoxArea;
        public PictureBox hitBoxMonster;
        public PictureBox hitBoxWave;
        public Label labelDescriptionHp;
        public Label labelDialogWindow;
        public List<PictureBox> hitBoxsButtons;
        public List<PictureBox> hitBoxsBoneAttacks;
        public List<PictureBox> hitBoxsGasterBlasterAttacks;
        public Image[] wavePhases = new[] {
                Опыты_над_слзданием_игры.Properties.Resources.spr_slice_o_0,
                Опыты_над_слзданием_игры.Properties.Resources.spr_slice_o_1,
                Опыты_над_слзданием_игры.Properties.Resources.spr_slice_o_2,
                Опыты_над_слзданием_игры.Properties.Resources.spr_slice_o_3,
                Опыты_над_слзданием_игры.Properties.Resources.spr_slice_o_4,
                Опыты_над_слзданием_игры.Properties.Resources.spr_slice_o_5,
                null
            };
        public Image[] kindsBones = new[]
        {
            Опыты_над_слзданием_игры.Properties.Resources.Bone,
            Опыты_над_слзданием_игры.Properties.Resources.Blue_bone
        };
        public Image[] kindsHeart = new[]
        {
            Опыты_над_слзданием_игры.Properties.Resources.PlayerRed,
            Опыты_над_слзданием_игры.Properties.Resources.PlayerBlue
        };
        public string[] dialogs = new[]
        {
            "Готов к спарингу?",
            "Ты действительно думал, что я буду \nстоять и принимать твои удары?",
            "Знаешь, у меня уже заканчивается \nперерыв. Давай ещё последнюю \nатаку применю и закругляемся",
            "Вот и всё. Будем считать, что ТЫ \nПОБЕДИЛ. Я пойду в бар Грилби. \nУвидимся, малой.",
            "Я ПОБЕДИЛ. Не расстраивайся. \nМожет следующий раз получится."
        };
        public bool isBlockingDialogWindow = false;

        public void InsertImage(PictureBox hitBox, Image image)
        {
            hitBox.Image = image;
        }

        public void PrepareSize(PictureBox[] hitBoxs, (int, int)[] sizes)
        {
            for (int i = 0; i < hitBoxs.Length; i++)
            {
                hitBoxs[i].Width = sizes[i].Item1;
                hitBoxs[i].Height = sizes[i].Item2;
            }
        }

        public Design(PictureBox hitBoxHeart, PictureBox hitBoxIndicationHealth, Label labelDescriptionHp, 
            Label labelDialogWindow, PictureBox hitBoxArea, PictureBox hitBoxMonster, PictureBox hitBoxWave)
        {
            this.hitBoxHeart = hitBoxHeart;
            this.hitBoxIndicationHealth = hitBoxIndicationHealth;
            this.labelDescriptionHp = labelDescriptionHp;
            this.labelDialogWindow = labelDialogWindow;
            this.hitBoxArea = hitBoxArea; 
            this.hitBoxMonster = hitBoxMonster;
            this.hitBoxWave = hitBoxWave;
        }

        public void Spawn(PictureBox[] hitBoxs, (int, int)[] coordinate)
        {
            for (int i = 0; i < hitBoxs.Length; i++)
            {
                hitBoxs[i].Left = coordinate[i].Item1;
                hitBoxs[i].Top = coordinate[i].Item2;
                hitBoxs[i].Visible = true;
            }
        }

        public void Disspawn(PictureBox[] hitBoxs)
        {
            for (int i = 0; i < hitBoxs.Length; i++)
            {
                hitBoxs[i].Left = 0;
                hitBoxs[i].Height = 0;
                hitBoxs[i].Visible = false;
            }
        }

        public void CreateHitBoxsBoneAttacks(params PictureBox[] boneAttacks)
        {
            hitBoxsBoneAttacks = boneAttacks.ToList();
        }

        public void CreateHitBoxsGasterBlasterAttacks (params PictureBox[] gasterBlasterAttacks)
        {
            hitBoxsGasterBlasterAttacks = gasterBlasterAttacks.ToList();
        }

        public void CreateHitBoxsButtons(params PictureBox[] buttons)
        {
            hitBoxsButtons = buttons.ToList();
        }

        public void SwapParameterVisible(PictureBox hitBox)
        {
            hitBox.Visible = !hitBox.Visible;
        }

        public void SelectButtonFight(bool isIntersection)
        {
            if (isIntersection)
                hitBoxsButtons[0].Image = Опыты_над_слзданием_игры.Properties.Resources.fightbt_1;
            else
                hitBoxsButtons[0].Image = Опыты_над_слзданием_игры.Properties.Resources.fightbt_0;
        }

        public void UpdateInformationHP(int health)
        {
            labelDescriptionHp.Text = health + "/20";
            hitBoxIndicationHealth.Width = health * 3;
        }

        public void TryChangeColorHeart(bool isBlue)
        {
            if (isBlue)
                hitBoxHeart.Image = kindsHeart[1];
            else
                hitBoxHeart.Image = kindsHeart[0];
        }

        public void TryChangeColorBone(PictureBox hitBoxBone, bool isBlue)
        {
            if (isBlue)
                hitBoxBone.Image = kindsBones[1];
            else
                hitBoxBone.Image = kindsBones[0];
        }


    }

    public partial class SansSparing
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        /// 

        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SansSparing));
            fieldBattle = new PictureBox();
            gameTimer = new System.Windows.Forms.Timer(components);
            sans = new PictureBox();
            singleBone1 = new PictureBox();
            healthСapacity = new PictureBox();
            indicationHealth = new PictureBox();
            ButtonFight = new PictureBox();
            heart = new PictureBox();
            Dodge = new System.Windows.Forms.Timer(components);
            waveKnife = new PictureBox();
            singleBone4 = new PictureBox();
            singleBone3 = new PictureBox();
            singleBone2 = new PictureBox();
            descriptionHp = new Label();
            dialogWindow = new Label();
            ((System.ComponentModel.ISupportInitialize)fieldBattle).BeginInit();
            ((System.ComponentModel.ISupportInitialize)sans).BeginInit();
            ((System.ComponentModel.ISupportInitialize)singleBone1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)healthСapacity).BeginInit();
            ((System.ComponentModel.ISupportInitialize)indicationHealth).BeginInit();
            ((System.ComponentModel.ISupportInitialize)ButtonFight).BeginInit();
            ((System.ComponentModel.ISupportInitialize)heart).BeginInit();
            ((System.ComponentModel.ISupportInitialize)waveKnife).BeginInit();
            ((System.ComponentModel.ISupportInitialize)singleBone4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)singleBone3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)singleBone2).BeginInit();
            SuspendLayout();
            // 
            // fieldBattle
            // 
            fieldBattle.BorderStyle = BorderStyle.FixedSingle;
            fieldBattle.Location = new Point(171, 403);
            fieldBattle.Name = "fieldBattle";
            fieldBattle.Size = new Size(937, 328);
            fieldBattle.TabIndex = 1;
            fieldBattle.TabStop = false;
            // 
            // gameTimer
            // 
            gameTimer.Enabled = true;
            gameTimer.Tick += MainGameTimer;
            // 
            // sans
            // 
            sans.Image = (Image)resources.GetObject("sans.Image");
            sans.Location = new Point(534, 101);
            sans.Name = "sans";
            sans.Size = new Size(220, 213);
            sans.SizeMode = PictureBoxSizeMode.Zoom;
            sans.TabIndex = 3;
            sans.TabStop = false;
            // 
            // singleBone1
            // 
            singleBone1.Image = Опыты_над_слзданием_игры.Properties.Resources.Bone;
            singleBone1.Location = new Point(12, 349);
            singleBone1.Name = "singleBone1";
            singleBone1.Size = new Size(57, 105);
            singleBone1.SizeMode = PictureBoxSizeMode.StretchImage;
            singleBone1.TabIndex = 4;
            singleBone1.TabStop = false;
            singleBone1.Tag = "damagingObject";
            singleBone1.Visible = false;
            // 
            // healthСapacity
            // 
            healthСapacity.BackColor = Color.Red;
            healthСapacity.Location = new Point(631, 768);
            healthСapacity.Name = "healthСapacity";
            healthСapacity.Size = new Size(60, 42);
            healthСapacity.TabIndex = 5;
            healthСapacity.TabStop = false;
            // 
            // indicationHealth
            // 
            indicationHealth.BackColor = Color.Yellow;
            indicationHealth.Location = new Point(631, 768);
            indicationHealth.Name = "indicationHealth";
            indicationHealth.Size = new Size(60, 42);
            indicationHealth.TabIndex = 6;
            indicationHealth.TabStop = false;
            // 
            // ButtonFight
            // 
            ButtonFight.Image = Опыты_над_слзданием_игры.Properties.Resources.fightbt_0;
            ButtonFight.Location = new Point(534, 497);
            ButtonFight.Name = "ButtonFight";
            ButtonFight.Size = new Size(228, 74);
            ButtonFight.SizeMode = PictureBoxSizeMode.StretchImage;
            ButtonFight.TabIndex = 2;
            ButtonFight.TabStop = false;
            // 
            // heart
            // 
            heart.Image = Опыты_над_слзданием_игры.Properties.Resources.PlayerRed;
            heart.Location = new Point(643, 611);
            heart.Name = "heart";
            heart.Size = new Size(26, 26);
            heart.SizeMode = PictureBoxSizeMode.StretchImage;
            heart.TabIndex = 8;
            heart.TabStop = false;
            // 
            // waveKnife
            // 
            waveKnife.BackColor = Color.Transparent;
            waveKnife.Location = new Point(617, 128);
            waveKnife.Name = "waveKnife";
            waveKnife.Size = new Size(52, 131);
            waveKnife.TabIndex = 9;
            waveKnife.TabStop = false;
            waveKnife.Visible = false;
            // 
            // singleBone4
            // 
            singleBone4.Image = Опыты_над_слзданием_игры.Properties.Resources.Bone;
            singleBone4.Location = new Point(1209, 530);
            singleBone4.Name = "singleBone4";
            singleBone4.Size = new Size(57, 201);
            singleBone4.SizeMode = PictureBoxSizeMode.StretchImage;
            singleBone4.TabIndex = 10;
            singleBone4.TabStop = false;
            singleBone4.Tag = "damagingObject";
            singleBone4.Visible = false;
            // 
            // singleBone3
            // 
            singleBone3.Image = Опыты_над_слзданием_игры.Properties.Resources.Bone;
            singleBone3.Location = new Point(1209, 349);
            singleBone3.Name = "singleBone3";
            singleBone3.Size = new Size(57, 105);
            singleBone3.SizeMode = PictureBoxSizeMode.StretchImage;
            singleBone3.TabIndex = 11;
            singleBone3.TabStop = false;
            singleBone3.Tag = "damagingObject";
            singleBone3.Visible = false;
            // 
            // singleBone2
            // 
            singleBone2.Image = Опыты_над_слзданием_игры.Properties.Resources.Bone;
            singleBone2.Location = new Point(12, 530);
            singleBone2.Name = "singleBone2";
            singleBone2.Size = new Size(57, 201);
            singleBone2.SizeMode = PictureBoxSizeMode.StretchImage;
            singleBone2.TabIndex = 12;
            singleBone2.TabStop = false;
            singleBone2.Tag = "damagingObject";
            singleBone2.Visible = false;
            // 
            // descriptionHp
            // 
            descriptionHp.AutoSize = true;
            descriptionHp.ForeColor = Color.Yellow;
            descriptionHp.Location = new Point(697, 768);
            descriptionHp.Name = "descriptionHp";
            descriptionHp.Size = new Size(65, 30);
            descriptionHp.TabIndex = 13;
            descriptionHp.Text = "20/20";
            // 
            // dialogWindow
            // 
            dialogWindow.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            dialogWindow.AutoSize = true;
            dialogWindow.BackColor = SystemColors.ButtonFace;
            dialogWindow.BorderStyle = BorderStyle.FixedSingle;
            dialogWindow.Cursor = Cursors.PanNW;
            dialogWindow.Font = new Font("Comic Sans MS", 11F, FontStyle.Regular, GraphicsUnit.Point, 204);
            dialogWindow.ForeColor = Color.Black;
            dialogWindow.Location = new Point(811, 128);
            dialogWindow.Name = "dialogWindow";
            dialogWindow.Size = new Size(208, 32);
            dialogWindow.TabIndex = 14;
            dialogWindow.Text = "Готов к спарингу?";
            dialogWindow.TextAlign = ContentAlignment.TopCenter;
            dialogWindow.Visible = false;
            // 
            // SansSparing
            // 
            AutoScaleDimensions = new SizeF(144F, 144F);
            AutoScaleMode = AutoScaleMode.Dpi;
            AutoSizeMode = AutoSizeMode.GrowAndShrink;
            BackColor = SystemColors.ActiveCaptionText;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            ClientSize = new Size(1285, 929);
            Controls.Add(dialogWindow);
            Controls.Add(descriptionHp);
            Controls.Add(singleBone2);
            Controls.Add(singleBone3);
            Controls.Add(singleBone4);
            Controls.Add(waveKnife);
            Controls.Add(heart);
            Controls.Add(ButtonFight);
            Controls.Add(indicationHealth);
            Controls.Add(healthСapacity);
            Controls.Add(singleBone1);
            Controls.Add(sans);
            Controls.Add(fieldBattle);
            Name = "SansSparing";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Sans's sparing";
            KeyDown += KeyIsDown;
            KeyUp += KeyIsUp;
            ((System.ComponentModel.ISupportInitialize)fieldBattle).EndInit();
            ((System.ComponentModel.ISupportInitialize)sans).EndInit();
            ((System.ComponentModel.ISupportInitialize)singleBone1).EndInit();
            ((System.ComponentModel.ISupportInitialize)healthСapacity).EndInit();
            ((System.ComponentModel.ISupportInitialize)indicationHealth).EndInit();
            ((System.ComponentModel.ISupportInitialize)ButtonFight).EndInit();
            ((System.ComponentModel.ISupportInitialize)heart).EndInit();
            ((System.ComponentModel.ISupportInitialize)waveKnife).EndInit();
            ((System.ComponentModel.ISupportInitialize)singleBone4).EndInit();
            ((System.ComponentModel.ISupportInitialize)singleBone3).EndInit();
            ((System.ComponentModel.ISupportInitialize)singleBone2).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox fieldBattle;
        private System.Windows.Forms.Timer gameTimer;
        private PictureBox sans;
        private PictureBox singleBone1;
        private PictureBox healthСapacity;
        private PictureBox indicationHealth;
        private PictureBox ButtonFight;
        private PictureBox heart;
        private System.Windows.Forms.Timer Dodge;
        private PictureBox waveKnife;
        private PictureBox singleBone4;
        private PictureBox singleBone3;
        private PictureBox singleBone2;
        private Label descriptionHp;
        private Label dialogWindow;
    }
}

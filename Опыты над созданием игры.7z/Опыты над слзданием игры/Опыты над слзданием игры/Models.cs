﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using Опыты_над_созданием_игры;

namespace Опыты_над_слзданием_игры
{
    public class Player
    {
        public int health;
        public int speed;
        public int heal;
        public int maxJumpSpeed;
        public int minFallSpeed;
        public int jumpSpeed;
        public int fallSpeed;
        public bool isBlue = false;
        public bool isClicked = false;

        public bool goLeft = false;
        public bool goRight = false;
        public bool goUp = false;
        public bool goDown = false;
        public bool jumping = false;
        public bool falling = false;


        int force;

        public Player(int speed = 27, int health = 20, int heal = 3, int jumpSpeed  = 20, int fallSpeed = 10)
        {
            this.speed = speed;
            this.health = health;
            this.heal = heal;
            this.jumpSpeed = jumpSpeed;
            this.fallSpeed = fallSpeed;
            this.maxJumpSpeed = jumpSpeed;
            this.minFallSpeed = fallSpeed;
        }


        public bool IsStopped()
        {
            return goLeft || goRight || goUp || goDown;
        }
    }

    public class Monster
    {
        public List<Bone> bones;
        public int deafultLeft = 534;
        private int level;
        public int numberAttack = -1;
        public int speedKarma;
        public int indexAttack = 0;
        public int timeAttack = 100; //100
        public int timerAttack = 0;
        public bool preparedSizeAttack = false;
        public bool isAttacking = false;
        public bool isDodging = false;
        public bool endedAttack = false;

        
        


        public Monster(int level = 1, int speedKarma = 1)
        {
            this.level = level;
            this.speedKarma = speedKarma;
            this.bones = new List<Bone>();
        }

        public void InitializeBones(params Bone[] bones)
        {
            foreach (var bone in bones)
            {
                bone.speed += level;
                this.bones.Add(bone);
            }
        }

        public int Damage(PictureBox hitBoxBone, PictureBox hitBoxPlayer, Design design, bool isStopped)
        {
            if (hitBoxBone.Bounds.IntersectsWith(hitBoxPlayer.Bounds) && (hitBoxBone.Image != design.kindsBones[1]
                || hitBoxBone.Image == design.kindsBones[1] && isStopped))
            {
                return speedKarma;
            }
            return 0;

        }

        public void SwapModPlayer(Player player)
        {
            player.isBlue = !player.isBlue;
        }

        /*public void SwapModBone(PictureBox hitBoxBone, Bone bone)
        {
            if (bone.isBlue)
            {
                bone.isBlue = false;
                hitBoxBone = Опыты_над_слзданием_игры.Properties.Resources.Bone;
            }
            else
            {
                bone.isBlue = true;
                bone.model.Image = Опыты_над_слзданием_игры.Properties.Resources.Blue_bone;
            }

        }*/
    }

    public static class WaveKnife
    {
        public static int numberPhaseWave = 0;
    }

    

    public class Bone
    {
        public int speed;

        public bool isSpawn = false;

        public bool isBlue = false;

        public bool isReverseMotion = true;

        public Direction direction = Direction.Right;

        public int Left;
        

        public Bone(int speed = 1, bool isBlue = false)
        {
            this.speed = speed;
            this.isBlue = isBlue;
        }

        /*public void Spawn(int x, int y)
        {
            Left = x;
            Top = y;
            isSpawn = true;
        }*/
    }

}

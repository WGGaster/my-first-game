﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace Опыты_над_слзданием_игры
{
    public partial class Form1
    {
        
    }
}

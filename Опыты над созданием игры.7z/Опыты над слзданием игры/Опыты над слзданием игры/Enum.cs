﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Опыты_над_слзданием_игры
{ 
    public enum Direction
    {
        Left = -1,
        Right = 1,
        Up,
        Down 
    }; 
}

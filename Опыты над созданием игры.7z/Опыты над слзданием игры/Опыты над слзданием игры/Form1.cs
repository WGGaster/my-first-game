using System.Media;
using System.Reflection.Emit;
using System.Security.Policy;
using System.Threading;
using System.Windows.Forms;
using Опыты_над_слзданием_игры;
using static System.Formats.Asn1.AsnWriter;

namespace Опыты_над_созданием_игры
{
    public partial class SansSparing : Form
    {
        Player player;
        Monster monster;
        Design design;
        

        public void InitializeCharacters()
        {

            if (player == null)
            {
                player = new Player();
                player.fallSpeed = 20;
            }


            if (design == null)
            {
                design = new Design(heart, indicationHealth, descriptionHp, dialogWindow, fieldBattle, sans, waveKnife);
                design.CreateHitBoxsBoneAttacks(singleBone1, singleBone2, singleBone3, singleBone4);
                design.CreateHitBoxsButtons(ButtonFight);
            }

            if (monster == null)
            {
                monster = new Monster(20);
                monster.InitializeBones(new Bone(15), new Bone(15), new Bone(15), new Bone(15));
            }
        }

        public bool IsIntersection(PictureBox hitbox1, PictureBox hitbox2)
        {
            return hitbox1.Bounds.IntersectsWith(hitbox2.Bounds);
        }

        public void Draw()
        {
            design.UpdateInformationHP(player.health);
            design.TryChangeColorHeart(player.isBlue);
            design.SelectButtonFight(IsIntersection(design.hitBoxsButtons[0], design.hitBoxHeart));
        }

        public void AttackPlayer()
        {
            if (!(monster.isAttacking || monster.isDodging) && !monster.endedAttack)
            {
                design.hitBoxsButtons[0].Visible = true;
                design.labelDialogWindow.Text = design.dialogs[monster.numberAttack + 1];
                design.labelDialogWindow.Visible = true;
                if (IsIntersection(design.hitBoxsButtons[0], design.hitBoxHeart) && player.isClicked)
                {
                    ActionMonster.MoveMonsterRight(design.hitBoxMonster, design.hitBoxWave, 15);
                    design.hitBoxsButtons[0].Visible = false;
                    design.labelDialogWindow.Visible = false;
                    monster.isDodging = true;
                    design.hitBoxWave.Visible = true;
                }
            }
            if (monster.isDodging)
            {
                if (WaveKnife.numberPhaseWave < design.wavePhases.Length)
                {
                    design.InsertImage(design.hitBoxWave, design.wavePhases[WaveKnife.numberPhaseWave]);
                    WaveKnife.numberPhaseWave++;
                }
                else
                {
                    WaveKnife.numberPhaseWave = 0;
                    monster.isAttacking = true;
                    monster.isDodging = false;
                    monster.numberAttack++;
                    design.hitBoxWave.Visible = false;
                    ActionMonster.MoveMonsterLeft(design.hitBoxMonster, monster.deafultLeft, 15);
                }
            }
        }

        public void StopAttackMonster(PictureBox[] hitBoxs)
        {
            if (monster.timerAttack > monster.timeAttack)
            {
                monster.timerAttack = 0;
                monster.isAttacking = false;
                monster.preparedSizeAttack = false;
                design.Disspawn(hitBoxs);
                SetDeafultValueBone(monster.bones);
            }
        }

        public void SetDeafultValueBone(List<Bone> bones)
        {
            foreach (var bone in bones)
            {
                bone.direction = Direction.Right;
                bone.isBlue = false;
                bone.isReverseMotion = true;
            }
        }

        public void AttackMonster()
        {
            if (monster.endedAttack)
            { 
            }
            if (monster.numberAttack == 0)
            {
                if (!monster.preparedSizeAttack)
                {
                    design.PrepareSize([design.hitBoxsBoneAttacks[0]],
                    new[] { (design.hitBoxsBoneAttacks[0].Width, design.hitBoxArea.Height * 3 / 4) });
                    design.Spawn([design.hitBoxsBoneAttacks[0]],
                        new[] { (design.hitBoxArea.Left, design.hitBoxArea.Top) });
                    monster.preparedSizeAttack = true;
                }
                
                ActionMonster.Attack1(monster.bones[0], design, 0);
                StopAttackMonster([design.hitBoxsBoneAttacks[0]]);
            }
            if (monster.numberAttack == 1)
            {
                if (!player.isBlue)
                {
                    player.isBlue = true;
                    design.TryChangeColorHeart(player.isBlue);
                }
                if (!monster.preparedSizeAttack)
                {
                    design.PrepareSize(design.hitBoxsBoneAttacks.Take(4).ToArray(),
                    new[] { 
                        (design.hitBoxsBoneAttacks[0].Width / 2, design.hitBoxArea.Height / 3),
                        (design.hitBoxsBoneAttacks[0].Width / 2, design.hitBoxArea.Height / 2),
                        (design.hitBoxsBoneAttacks[0].Width / 2, design.hitBoxArea.Height / 2),
                        (design.hitBoxsBoneAttacks[0].Width / 2, design.hitBoxArea.Height / 3)
                    });
                    design.Spawn(design.hitBoxsBoneAttacks.Take(4).ToArray(),
                    new[]
                    {
                        (design.hitBoxArea.Left, design.hitBoxArea.Top),
                        (design.hitBoxArea.Left, design.hitBoxArea.Top + design.hitBoxArea.Height 
                        - design.hitBoxsBoneAttacks[1].Height),
                        (design.hitBoxArea.Left + design.hitBoxArea.Width, design.hitBoxArea.Top),
                        (design.hitBoxArea.Left + design.hitBoxArea.Width, design.hitBoxArea.Top + design.hitBoxArea.Height
                        - design.hitBoxsBoneAttacks[3].Height)
                    });
                    monster.preparedSizeAttack = true;
                }
                ActionMonster.Attack2(monster.bones, design);
                StopAttackMonster(design.hitBoxsBoneAttacks.Take(4).ToArray());
            }
            if (monster.numberAttack == 2)
            {
                if (!monster.preparedSizeAttack)
                {
                    design.PrepareSize(design.hitBoxsBoneAttacks.Take(4).ToArray(),
                    new[] {
                        (design.hitBoxsBoneAttacks[0].Width, design.hitBoxArea.Height / 10),
                        (design.hitBoxsBoneAttacks[0].Width, design.hitBoxArea.Height * 4 / 5),
                        (design.hitBoxsBoneAttacks[0].Width, design.hitBoxArea.Height / 10),
                        (design.hitBoxsBoneAttacks[0].Width, design.hitBoxArea.Height * 4 / 5)
                    });
                    design.Spawn(design.hitBoxsBoneAttacks.Take(4).ToArray(),
                    new[]
                    {
                        (design.hitBoxArea.Left, design.hitBoxArea.Top + design.hitBoxArea.Height
                        - design.hitBoxsBoneAttacks[0].Height),
                        (design.hitBoxArea.Left, design.hitBoxArea.Top + design.hitBoxArea.Height
                        - design.hitBoxsBoneAttacks[1].Height),
                        (design.hitBoxArea.Left, design.hitBoxArea.Top + design.hitBoxArea.Height
                        - design.hitBoxsBoneAttacks[2].Height),
                        (design.hitBoxArea.Left, design.hitBoxArea.Top + design.hitBoxArea.Height
                        - design.hitBoxsBoneAttacks[3].Height)
                    });
                    monster.bones[1].isBlue = true;
                    monster.bones[3].isBlue = true;
                    monster.preparedSizeAttack = true;
                }
                ActionMonster.Attack3(monster.bones, design, monster.timerAttack);
                StopAttackMonster(design.hitBoxsBoneAttacks.Take(4).ToArray());
            }
            monster.timerAttack++;

            foreach (Control x in this.Controls)
            {
                if ((string)x.Tag == "damagingObject")
                {
                    player.health -= monster.Damage((PictureBox)x, design.hitBoxHeart, design, player.IsStopped());
                }
            }
            CheckGameOver();
            if (monster.endedAttack && monster.isAttacking)
            {
                StopAttackMonster(design.hitBoxsBoneAttacks.ToArray());
                monster.isAttacking = false;
            }
        }

        public void Attack()
        {
            AttackPlayer();
            if (monster.isAttacking)
                AttackMonster();
        }

        public void CheckGameOver()
        {
            if (player.health <= 1 || (monster.numberAttack == 2 && !monster.isAttacking))
            {
                monster.endedAttack = true;
            }
        }

        public void End()
        {
            if (monster.endedAttack)
            {
                var indexFinalDialog = 0;
                if (player.isClicked)
                {
                    design.isBlockingDialogWindow = true;
                    design.labelDialogWindow.Visible = false;
                }

                if (player.health <= 1)
                {
                    indexFinalDialog = design.dialogs.Length - 1;
                }
                if (monster.numberAttack == 2 && !monster.isAttacking)
                {
                    indexFinalDialog = monster.numberAttack + 1;
                }

                if (!design.isBlockingDialogWindow)
                {
                    design.labelDialogWindow.Text = design.dialogs[indexFinalDialog];
                    design.labelDialogWindow.Visible = true;
                }
                
                if (design.isBlockingDialogWindow)
                {
                    ActionMonster.MoveMonsterLeft(design.hitBoxMonster, -1000, 5);
                }
            }
            
        }

        public SansSparing()
        {
            InitializeComponent();
        }

        private void MainGameTimer(object sender, EventArgs e)
        {
            InitializeCharacters();
            Draw();
            Move();
            Attack();
            End();
            
        }

        private void Move()
        {
            if (player.goLeft && fieldBattle.Left < heart.Left)
            {
                heart.Left -= fieldBattle.Left < heart.Left - player.speed
                    ? player.speed : heart.Left - fieldBattle.Left;
            }
            if (player.goRight && heart.Left + heart.Width < fieldBattle.Left + fieldBattle.Width)
            {
                heart.Left += heart.Left + heart.Width + player.speed < fieldBattle.Left + fieldBattle.Width
                    ? player.speed : fieldBattle.Left + fieldBattle.Width - (heart.Left + heart.Width);
            }
            if (player.goUp && fieldBattle.Top < heart.Top && !player.isBlue)
            {
                heart.Top -= fieldBattle.Top < heart.Top - player.speed
                    ? player.speed : heart.Top - fieldBattle.Top;
            }
            if (player.goDown && heart.Top + heart.Height < fieldBattle.Top + fieldBattle.Height && !player.isBlue)
            {
                heart.Top += heart.Top + heart.Height + player.speed < fieldBattle.Top + fieldBattle.Height
                    ? player.speed : fieldBattle.Top + fieldBattle.Height - (heart.Top + heart.Height);
            }
            if (player.jumping && player.jumpSpeed > 0)
            {
                heart.Top -= player.jumpSpeed;
                player.jumpSpeed -= 1;
            }
            if (!player.jumping || player.jumpSpeed == 0)
            {
                player.falling = true;
                player.jumpSpeed = 0;
            }
            if (player.falling
                && heart.Top + heart.Height < fieldBattle.Top + fieldBattle.Height && player.isBlue)
            {
                heart.Top += heart.Top + heart.Height + player.fallSpeed < fieldBattle.Top + fieldBattle.Height
                    ? player.fallSpeed : fieldBattle.Top + fieldBattle.Height - (heart.Top + heart.Height);
                player.fallSpeed++;
            }

            if (heart.Top + heart.Height >= fieldBattle.Top + fieldBattle.Height && player.isBlue)
            {
                player.falling = false;
                player.jumpSpeed = player.maxJumpSpeed;
                player.fallSpeed = player.minFallSpeed;
            }
        }

        private bool CheckKey(KeyEventArgs e, Keys key)
        {
            return e.KeyCode == key;
        }

        private void KeyIsDown(object sender, KeyEventArgs e)
        {
            if (CheckKey(e, Keys.Left) || CheckKey(e, Keys.A))
            {
                player.goLeft = true;
            }
            if (CheckKey(e, Keys.Right) || CheckKey(e, Keys.D))
            {
                player.goRight = true;
            }
            if (CheckKey(e, Keys.Up) || CheckKey(e, Keys.W) && !player.isBlue)
            {
                player.goUp = true;
            }
            if (CheckKey(e, Keys.Down) || CheckKey(e, Keys.S) && !player.isBlue)
            {
                player.goDown = true;
            }
            if (CheckKey(e, Keys.Z) || CheckKey(e, Keys.Enter))
            {
                player.isClicked = true;
            }
            if (CheckKey(e, Keys.Up) || CheckKey(e, Keys.W) && player.isBlue && !player.jumping)
            {
                player.jumping = true;
            }
        }

        private void KeyIsUp(object sender, KeyEventArgs e)
        {
            if (CheckKey(e, Keys.Left) || CheckKey(e, Keys.A))
            {
                player.goLeft = false;
            }
            if (CheckKey(e, Keys.Right) || CheckKey(e, Keys.D))
            {
                player.goRight = false;
            }
            if (e.KeyCode == Keys.Up || CheckKey(e, Keys.W))
            {
                player.goUp = false;
            }
            if (e.KeyCode == Keys.Down || CheckKey(e, Keys.S))
            {
                player.goDown = false;
            }
            if (CheckKey(e, Keys.Z) || CheckKey(e, Keys.Enter))
            {
                player.isClicked = false;
            }
            if (CheckKey(e, Keys.Up) || CheckKey(e, Keys.W) && player.isBlue)
            {
                player.jumping = false;
            }
        }

        
    }
}
